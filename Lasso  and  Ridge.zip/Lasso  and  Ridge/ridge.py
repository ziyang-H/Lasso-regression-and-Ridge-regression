import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.linear_model import Ridge
from sklearn import datasets, linear_model
from sklearn.model_selection import train_test_split

#data = np.loadtxt('data/Adv.csv', delimiter=',')
data = pd.read_csv('data/Adv.csv')
x = data[['TV', 'radio', 'newspaper']]
y = data[['sales']]

xx=np.arange(200)
plt.xlabel("all sample")
plt.ylabel("value")
plt.scatter(xx,y)
plt.show()
plt.clf()

x_train, x_test, y_train, y_test = train_test_split(x, y, random_state=1)
ridge = Ridge(alpha=1)
ridge.fit(x_train, y_train)
print (ridge.coef_)
print (ridge.intercept_)

# training regression result
xx = np.array(np.arange(150))
plt.xlabel("train_sample")
plt.ylabel("price")
plt.scatter(xx, y_train, marker='x')
plt.plot(xx, ridge.predict(x_train), c='r')
plt.savefig('ridge_train_result.png')
plt.clf()

# regression result
xx=np.arange(50)
plt.xlabel("test_sample")
plt.ylabel("price")
plt.scatter(xx, y_test, marker='x')
plt.plot(xx, ridge.predict(x_test),c='r')
plt.savefig('ridge_test_result.png')
plt.clf()

import sklearn.metrics as sm
# training set regression condition
print('Mean squared error', sm.mean_squared_error(y_train, ridge.predict(x_train)))
print('Mean squared error', sm.median_absolute_error(y_train, ridge.predict(x_train)))


# testing set regression condition
print('MSE', sm.mean_squared_error(y_test, ridge.predict(x_test)))
print('RMSE', sm.median_absolute_error(y_test, ridge.predict(x_test)))

from sklearn.linear_model import RidgeCV
ridgecv = RidgeCV(alphas=[0.01, 0.1, 0.5, 1, 3, 5, 7, 10, 20, 100])
ridgecv.fit(x_train, y_train)
print (ridgecv.alpha_)
