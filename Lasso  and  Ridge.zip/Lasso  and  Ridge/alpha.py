import numpy  as np
import matplotlib.pyplot as plt
from sklearn import linear_model
X=1./(np.arange(1,11)+np.arange(0,10)[:,np.newaxis])
y=np.ones(10)
n_alpha=200
alpha=np.logspace(-10,-2,n_alpha)
clf=linear_model.Ridge(fit_intercept=False)
coefs=[]
for a in alpha:
    clf.set_params(alpha=a)
    clf.fit(X,y)
    coefs.append(clf.coef_)
ax=plt.gca()
ax.plot(alpha,coefs)
ax.set_xscale('log')
ax.set_xlim(ax.get_xlim()[::-1])
plt.xlabel('alpha')
plt.ylabel('weights')
plt.title('Ridge coefficients as a function of the regularization')
plt.axis('tight')
plt.show()